@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.galeshapley.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.galeshapley.model.MatchingResult
import com.example.galeshapley.model.Outcome
import com.example.galeshapley.model.TraceStep
import com.example.galeshapley.viewmodel.GaleShapleyViewModel
import com.example.galeshapley.viewmodel.RunMode
import com.example.galeshapley.viewmodel.Side

private val TAB_TITLES = listOf("Nodos", "Preferencias", "Resultado")

// ======================================================================
// Raíz
// ======================================================================

@Composable
fun GaleShapleyApp(vm: GaleShapleyViewModel = viewModel()) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }

    Scaffold(topBar = { TopAppBar(title = { Text("Matching estable") }) }) { padding ->
        Column(Modifier.padding(padding)) {
            TabRow(selectedTabIndex = tab) {
                TAB_TITLES.forEachIndexed { i, title ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(title) })
                }
            }
            when (tab) {
                0 -> ConfigTab(
                    uNames = state.proposerNames,
                    vNames = state.receiverNames,
                    onUCount = vm::setProposerCount,
                    onVCount = vm::setReceiverCount,
                    onRenameU = vm::renameProposer,
                    onRenameV = vm::renameReceiver
                )
                1 -> PreferencesTab(
                    uNames = state.proposerNames,
                    vNames = state.receiverNames,
                    uPrefs = state.proposerPrefs,
                    vPrefs = state.receiverPrefs,
                    onMove = vm::movePreference,
                    onShuffle = vm::randomizePreferences,
                    onReset = vm::resetPreferences
                )
                else -> ResultTab(
                    uNames = state.proposerNames,
                    vNames = state.receiverNames,
                    mode = state.mode,
                    result = state.result,
                    stepIndex = state.stepIndex,
                    error = state.error,
                    onMode = vm::setMode,
                    onSolve = vm::solve,
                    onPrev = vm::previousStep,
                    onNext = vm::nextStep,
                    onRestart = vm::restartSteps,
                    onEnd = vm::jumpToEnd
                )
            }
        }
    }
}

// ======================================================================
// Pestaña 1: configuración de vértices
// ======================================================================

@Composable
fun ConfigTab(
    uNames: List<String>,
    vNames: List<String>,
    onUCount: (Int) -> Unit,
    onVCount: (Int) -> Unit,
    onRenameU: (Int, String) -> Unit,
    onRenameV: (Int, String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { CountStepper("Proponentes (U)", uNames.size, onUCount) }
        itemsIndexed(uNames) { i, name ->
            OutlinedTextField(
                value = name,
                onValueChange = { onRenameU(i, it) },
                label = { Text("Proponente ${i + 1}") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item { Text("", Modifier.height(8.dp)) }
        item { CountStepper("Receptores (V)", vNames.size, onVCount) }
        itemsIndexed(vNames) { i, name ->
            OutlinedTextField(
                value = name,
                onValueChange = { onRenameV(i, it) },
                label = { Text("Receptor ${i + 1}") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun CountStepper(label: String, value: Int, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text(label, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        FilledTonalIconButton(
            onClick = { onChange(value - 1) },
            enabled = value > 1
        ) { Text("−", style = MaterialTheme.typography.titleLarge) }
        Text("$value", modifier = Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.titleMedium)
        FilledTonalIconButton(
            onClick = { onChange(value + 1) },
            enabled = value < GaleShapleyViewModel.MAX_NODES
        ) { Icon(Icons.Default.Add, contentDescription = "Añadir nodo") }
    }
}

// ======================================================================
// Pestaña 2: matriz de preferencias
// ======================================================================

@Composable
fun PreferencesTab(
    uNames: List<String>,
    vNames: List<String>,
    uPrefs: List<List<Int>>,
    vPrefs: List<List<Int>>,
    onMove: (Side, Int, Int, Int) -> Unit,
    onShuffle: () -> Unit,
    onReset: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onShuffle) { Text("Aleatorizar") }
                TextButton(onClick = onReset) { Text("Restablecer orden") }
            }
        }
        item { Text("Proponentes: de más a menos preferido", style = MaterialTheme.typography.titleMedium) }
        itemsIndexed(uPrefs) { u, order ->
            PreferenceCard(uNames[u], order, vNames) { from, to -> onMove(Side.PROPOSERS, u, from, to) }
        }
        item { Text("Receptores: de más a menos preferido", style = MaterialTheme.typography.titleMedium) }
        itemsIndexed(vPrefs) { v, order ->
            PreferenceCard(vNames[v], order, uNames) { from, to -> onMove(Side.RECEIVERS, v, from, to) }
        }
    }
}

@Composable
fun PreferenceCard(
    owner: String,
    order: List<Int>,
    targetNames: List<String>,
    onMove: (from: Int, to: Int) -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Text(owner, style = MaterialTheme.typography.titleSmall)
            order.forEachIndexed { pos, target ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${pos + 1}.", modifier = Modifier.width(28.dp))
                    Text(targetNames.getOrElse(target) { "?" }, modifier = Modifier.weight(1f))
                    IconButton(onClick = { onMove(pos, pos - 1) }, enabled = pos > 0) {
                        Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Subir")
                    }
                    IconButton(onClick = { onMove(pos, pos + 1) }, enabled = pos < order.lastIndex) {
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Bajar")
                    }
                }
            }
        }
    }
}

// ======================================================================
// Pestaña 3: ejecución, traza, grafo y verificación
// ======================================================================

@Composable
fun ResultTab(
    uNames: List<String>,
    vNames: List<String>,
    mode: RunMode,
    result: MatchingResult?,
    stepIndex: Int,
    error: String?,
    onMode: (RunMode) -> Unit,
    onSolve: () -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onRestart: () -> Unit,
    onEnd: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            val modes = listOf(RunMode.DIRECT to "Directo", RunMode.STEP_BY_STEP to "Paso a paso")
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                modes.forEachIndexed { i, (m, label) ->
                    SegmentedButton(
                        selected = mode == m,
                        onClick = { onMode(m) },
                        shape = SegmentedButtonDefaults.itemShape(i, modes.size)
                    ) { Text(label) }
                }
            }
        }
        item { Button(onClick = onSolve, modifier = Modifier.fillMaxWidth()) { Text("Ejecutar Gale-Shapley") } }

        if (error != null) {
            item { Text(error, color = MaterialTheme.colorScheme.error) }
        }

        if (result == null) {
            if (error == null) item {
                Text("Ejecuta el algoritmo para ver el matching.", style = MaterialTheme.typography.bodyMedium)
            }
            return@LazyColumn
        }

        val total = result.trace.size
        val displayed = if (mode == RunMode.DIRECT) total else stepIndex.coerceIn(0, total)
        val currentStep = result.trace.getOrNull(displayed - 1)
        val matching = if (displayed == 0) emptyMap() else result.trace[displayed - 1].matching
        val isFinal = displayed == total

        item {
            BipartiteGraph(
                uNames = uNames,
                vNames = vNames,
                matching = matching,
                highlight = if (mode == RunMode.STEP_BY_STEP) currentStep else null
            )
        }

        if (mode == RunMode.STEP_BY_STEP) {
            item {
                StepControls(displayed, total, onPrev, onNext, onRestart, onEnd)
            }
            if (currentStep != null) {
                item {
                    Text(
                        "Cola de libres: " +
                            (currentStep.freeProposers.joinToString { uNames[it] }.ifEmpty { "vacía" }),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            itemsIndexed(result.trace.take(displayed).asReversed()) { idx, step ->
                TraceRow(step, uNames, vNames, isCurrent = idx == 0)
            }
        }

        if (isFinal) {
            item { MatchingSummary(result, uNames, vNames) }
            item { StabilityCard(result, uNames, vNames) }
        }
    }
}

@Composable
private fun StepControls(
    displayed: Int,
    total: Int,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onRestart: () -> Unit,
    onEnd: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            OutlinedButton(onClick = onPrev, enabled = displayed > 0) { Text("Anterior") }
            Text("Propuesta $displayed de $total", style = MaterialTheme.typography.titleSmall)
            Button(onClick = onNext, enabled = displayed < total) { Text("Siguiente") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = onRestart, enabled = displayed > 0) { Text("Reiniciar") }
            TextButton(onClick = onEnd, enabled = displayed < total) { Text("Ir al final") }
        }
    }
}

@Composable
private fun TraceRow(step: TraceStep, uNames: List<String>, vNames: List<String>, isCurrent: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isCurrent) MaterialTheme.colorScheme.secondaryContainer
            else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Text(
            text = "${step.number}. ${describe(step, uNames, vNames)}",
            modifier = Modifier.padding(12.dp),
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

private fun describe(step: TraceStep, uNames: List<String>, vNames: List<String>): String {
    val u = uNames[step.proposer]
    val v = vNames[step.receiver]
    return when (step.outcome) {
        Outcome.ACCEPTED_FREE ->
            "$u propone a $v. $v está libre y acepta de forma provisional."
        Outcome.REPLACED_PARTNER ->
            "$u propone a $v. $v prefiere a $u sobre ${uNames[step.dropped!!]}: " +
                "descarta a ${uNames[step.dropped]}, que vuelve a la cola."
        Outcome.REJECTED ->
            "$u propone a $v. $v prefiere a su pareja actual y rechaza a $u."
    }
}

@Composable
private fun MatchingSummary(result: MatchingResult, uNames: List<String>, vNames: List<String>) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Matching final μ: U → V", style = MaterialTheme.typography.titleSmall)
            result.matching.toSortedMap().forEach { (u, v) ->
                Text("μ(${uNames[u]}) = ${vNames[v]}")
            }
            if (result.unmatchedProposers.isNotEmpty())
                Text("Proponentes sin pareja: " + result.unmatchedProposers.joinToString { uNames[it] })
            if (result.unmatchedReceivers.isNotEmpty())
                Text("Receptores sin pareja: " + result.unmatchedReceivers.joinToString { vNames[it] })
            Text("Propuestas ejecutadas: ${result.proposalCount}", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun StabilityCard(result: MatchingResult, uNames: List<String>, vNames: List<String>) {
    val stable = result.isStable
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (stable) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.errorContainer
        )
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (stable) {
                Text("Matching estable", style = MaterialTheme.typography.titleSmall)
                Text("No existe ningún par bloqueante (u, v): ningún proponente y receptor se preferirían mutuamente a sus parejas actuales.")
            } else {
                Text("Matching inestable", style = MaterialTheme.typography.titleSmall)
                result.blockingPairs.forEach { (u, v) -> Text("Par bloqueante: (${uNames[u]}, ${vNames[v]})") }
            }
        }
    }
}

// ======================================================================
// Grafo bipartito
// ======================================================================

@Composable
fun BipartiteGraph(
    uNames: List<String>,
    vNames: List<String>,
    matching: Map<Int, Int>,
    highlight: TraceStep?,
    modifier: Modifier = Modifier
) {
    val rows = maxOf(uNames.size, vNames.size)
    val measurer = rememberTextMeasurer()
    val scheme = MaterialTheme.colorScheme
    val labelStyle = TextStyle(fontSize = 13.sp, color = scheme.onSurface)

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height((rows * 48 + 16).dp)
    ) {
        val leftX = size.width * 0.28f
        val rightX = size.width * 0.72f
        val radius = 14.dp.toPx()
        val labelWidth = (size.width * 0.22f).toInt()

        fun yOf(i: Int, count: Int) = size.height / count * (i + 0.5f)

        // Arista descartada en el paso actual (punteada, tenue).
        if (highlight?.dropped != null) {
            drawLine(
                color = scheme.outline,
                start = Offset(leftX, yOf(highlight.dropped, uNames.size)),
                end = Offset(rightX, yOf(highlight.receiver, vNames.size)),
                strokeWidth = 3.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
            )
        }

        // Asignación temporal / final.
        matching.forEach { (u, v) ->
            drawLine(
                color = scheme.primary,
                start = Offset(leftX, yOf(u, uNames.size)),
                end = Offset(rightX, yOf(v, vNames.size)),
                strokeWidth = 4.dp.toPx()
            )
        }

        // Propuesta rechazada en el paso actual.
        if (highlight != null && highlight.outcome == Outcome.REJECTED) {
            drawLine(
                color = scheme.error,
                start = Offset(leftX, yOf(highlight.proposer, uNames.size)),
                end = Offset(rightX, yOf(highlight.receiver, vNames.size)),
                strokeWidth = 3.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))
            )
        }

        // Nodos y etiquetas.
        uNames.forEachIndexed { i, name ->
            val c = Offset(leftX, yOf(i, uNames.size))
            val active = highlight?.proposer == i
            drawCircle(scheme.primaryContainer, radius, c)
            drawCircle(
                color = if (active) scheme.tertiary else scheme.primary,
                radius = radius, center = c,
                style = Stroke(width = (if (active) 4 else 2).dp.toPx())
            )
            val layout = measurer.measure(
                AnnotatedString(name), labelStyle, TextOverflow.Ellipsis, maxLines = 1,
                constraints = Constraints(maxWidth = labelWidth)
            )
            drawText(layout, topLeft = Offset(c.x - radius - 8.dp.toPx() - layout.size.width, c.y - layout.size.height / 2f))
        }
        vNames.forEachIndexed { i, name ->
            val c = Offset(rightX, yOf(i, vNames.size))
            val active = highlight?.receiver == i
            drawCircle(scheme.secondaryContainer, radius, c)
            drawCircle(
                color = if (active) scheme.tertiary else scheme.secondary,
                radius = radius, center = c,
                style = Stroke(width = (if (active) 4 else 2).dp.toPx())
            )
            val layout = measurer.measure(
                AnnotatedString(name), labelStyle, TextOverflow.Ellipsis, maxLines = 1,
                constraints = Constraints(maxWidth = labelWidth)
            )
            drawText(layout, topLeft = Offset(c.x + radius + 8.dp.toPx(), c.y - layout.size.height / 2f))
        }
    }
}
