package com.example.galeshapley.solver

import com.example.galeshapley.model.MatchingResult
import com.example.galeshapley.model.Outcome
import com.example.galeshapley.model.PreferenceProfile
import com.example.galeshapley.model.TraceStep

/**
 * Gale-Shapley (Deferred Acceptance), lado U proponente. Kotlin puro, sin dependencias de Android.
 *
 * Complejidad: O(n·m) propuestas, cada una en O(1) gracias a la tabla de rangos
 * rank[v][u] (construcción O(n·m)). Para n = m = N resulta O(N²).
 * Registrar la traza añade O(n) por paso en memoria (instantáneas para la UI);
 * se puede desactivar con recordTrace = false.
 */
object GaleShapleySolver {

    /** Devuelve null si el perfil es válido, o un mensaje de error en caso contrario. */
    fun validate(p: PreferenceProfile): String? {
        if (p.n == 0 || p.m == 0) return "Debe haber al menos un nodo en U y uno en V."
        if (p.proposerPrefs.size != p.n || p.receiverPrefs.size != p.m)
            return "Faltan listas de preferencia."
        val allV = (0 until p.m).toSet()
        val allU = (0 until p.n).toSet()
        for (u in 0 until p.n) {
            val list = p.proposerPrefs[u]
            if (list.size != p.m || list.toSet() != allV)
                return "La lista de ${p.proposers[u]} debe ordenar a todos los receptores sin repetir."
        }
        for (v in 0 until p.m) {
            val list = p.receiverPrefs[v]
            if (list.size != p.n || list.toSet() != allU)
                return "La lista de ${p.receivers[v]} debe ordenar a todos los proponentes sin repetir."
        }
        if (p.proposers.any { it.isBlank() } || p.receivers.any { it.isBlank() })
            return "Todos los nodos necesitan un nombre."
        if (p.proposers.toSet().size != p.n || p.receivers.toSet().size != p.m)
            return "Los nombres dentro de cada conjunto deben ser únicos."
        return null
    }

    fun solve(p: PreferenceProfile, recordTrace: Boolean = true): MatchingResult {
        validate(p)?.let { throw IllegalArgumentException(it) }
        val n = p.n
        val m = p.m

        // rank[v][u] = posición de u en la lista de v (menor = mejor).
        val rank = Array(m) { IntArray(n) }
        for (v in 0 until m) p.receiverPrefs[v].forEachIndexed { pos, u -> rank[v][u] = pos }

        val next = IntArray(n)            // siguiente índice de propuesta de cada u
        val matchU = IntArray(n) { -1 }   // μ(u)
        val matchV = IntArray(m) { -1 }   // μ⁻¹(v)
        val free = ArrayDeque<Int>((0 until n).toList())
        val trace = ArrayList<TraceStep>()
        var proposals = 0

        while (free.isNotEmpty()) {
            val u = free.removeFirst()
            if (next[u] >= m) continue    // u agotó su lista: queda sin pareja

            val v = p.proposerPrefs[u][next[u]++]
            proposals++
            val current = matchV[v]
            val outcome: Outcome
            var dropped: Int? = null

            when {
                current == -1 -> {
                    matchV[v] = u; matchU[u] = v
                    outcome = Outcome.ACCEPTED_FREE
                }
                rank[v][u] < rank[v][current] -> {
                    matchV[v] = u; matchU[u] = v
                    matchU[current] = -1
                    free.addLast(current)
                    dropped = current
                    outcome = Outcome.REPLACED_PARTNER
                }
                else -> {
                    free.addFirst(u)      // u sigue libre y propondrá al siguiente
                    outcome = Outcome.REJECTED
                }
            }

            if (recordTrace) {
                trace += TraceStep(
                    number = proposals,
                    proposer = u,
                    receiver = v,
                    outcome = outcome,
                    dropped = dropped,
                    matching = snapshot(matchU),
                    freeProposers = free.toList()
                )
            }
        }

        val matching = snapshot(matchU)
        return MatchingResult(
            matching = matching,
            unmatchedProposers = (0 until n).filter { matchU[it] == -1 },
            unmatchedReceivers = (0 until m).filter { matchV[it] == -1 },
            proposalCount = proposals,
            trace = trace,
            blockingPairs = findBlockingPairs(p, matching)
        )
    }

    /**
     * Pares bloqueantes (u, v): u prefiere v a μ(u) (o está libre) y
     * v prefiere u a μ⁻¹(v) (o está libre). Verificación independiente en O(n·m).
     */
    fun findBlockingPairs(p: PreferenceProfile, matching: Map<Int, Int>): List<Pair<Int, Int>> {
        val rankU = Array(p.n) { IntArray(p.m) }
        for (u in 0 until p.n) p.proposerPrefs[u].forEachIndexed { pos, v -> rankU[u][v] = pos }
        val rankV = Array(p.m) { IntArray(p.n) }
        for (v in 0 until p.m) p.receiverPrefs[v].forEachIndexed { pos, u -> rankV[v][u] = pos }
        val partnerOfV = IntArray(p.m) { -1 }
        matching.forEach { (u, v) -> partnerOfV[v] = u }

        val blocking = ArrayList<Pair<Int, Int>>()
        for (u in 0 until p.n) {
            val mu = matching[u]
            for (v in 0 until p.m) {
                if (v == mu) continue
                val uWants = mu == null || rankU[u][v] < rankU[u][mu]
                val vWants = partnerOfV[v] == -1 || rankV[v][u] < rankV[v][partnerOfV[v]]
                if (uWants && vWants) blocking += u to v
            }
        }
        return blocking
    }

    private fun snapshot(matchU: IntArray): Map<Int, Int> =
        buildMap { matchU.forEachIndexed { u, v -> if (v >= 0) put(u, v) } }
}
