package com.example.galeshapley.model

/**
 * Grafo bipartito G = (U, V, E) con listas de preferencia estrictas y completas.
 *
 * Los vértices se identifican por índice: u ∈ 0 until n, v ∈ 0 until m.
 * proposerPrefs[u] = receptores ordenados de más a menos preferido.
 * receiverPrefs[v] = proponentes ordenados de más a menos preferido.
 */
data class PreferenceProfile(
    val proposers: List<String>,
    val receivers: List<String>,
    val proposerPrefs: List<List<Int>>,
    val receiverPrefs: List<List<Int>>
) {
    val n: Int get() = proposers.size
    val m: Int get() = receivers.size
}

/** Resultado de una propuesta u → v. */
enum class Outcome {
    /** v estaba libre: acepta provisionalmente. */
    ACCEPTED_FREE,

    /** v prefiere a u sobre su pareja actual: la descarta y acepta a u. */
    REPLACED_PARTNER,

    /** v prefiere a su pareja actual: rechaza a u. */
    REJECTED
}

/** Una iteración del algoritmo (una propuesta) con instantánea del estado posterior. */
data class TraceStep(
    val number: Int,
    val proposer: Int,
    val receiver: Int,
    val outcome: Outcome,
    /** Proponente descartado por el receptor (solo si outcome == REPLACED_PARTNER). */
    val dropped: Int?,
    /** Asignación temporal μ tras el paso: u → v. */
    val matching: Map<Int, Int>,
    /** Cola de proponentes libres tras el paso (el primero propone a continuación). */
    val freeProposers: List<Int>
)

data class MatchingResult(
    /** μ: U → V (solo proponentes emparejados). */
    val matching: Map<Int, Int>,
    val unmatchedProposers: List<Int>,
    val unmatchedReceivers: List<Int>,
    val proposalCount: Int,
    /** Historial de propuestas ejecutadas. */
    val trace: List<TraceStep>,
    /** Pares bloqueantes (u, v); vacío ⇔ matching estable. */
    val blockingPairs: List<Pair<Int, Int>>
) {
    val isStable: Boolean get() = blockingPairs.isEmpty()
}
