package com.example.galeshapley.viewmodel

import androidx.lifecycle.ViewModel
import com.example.galeshapley.model.MatchingResult
import com.example.galeshapley.model.PreferenceProfile
import com.example.galeshapley.solver.GaleShapleySolver
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class RunMode { DIRECT, STEP_BY_STEP }
enum class Side { PROPOSERS, RECEIVERS }

data class GaleShapleyUiState(
    val proposerNames: List<String>,
    val receiverNames: List<String>,
    val proposerPrefs: List<List<Int>>,
    val receiverPrefs: List<List<Int>>,
    val mode: RunMode = RunMode.DIRECT,
    val result: MatchingResult? = null,
    /** Pasos ya aplicados en modo paso a paso (0 = estado inicial). */
    val stepIndex: Int = 0,
    val error: String? = null
) {
    val profile: PreferenceProfile
        get() = PreferenceProfile(proposerNames, receiverNames, proposerPrefs, receiverPrefs)
}

class GaleShapleyViewModel : ViewModel() {

    companion object {
        const val MAX_NODES = 12
    }

    private val _uiState = MutableStateFlow(initialState(3, 3))
    val uiState: StateFlow<GaleShapleyUiState> = _uiState.asStateFlow()

    // ---------- Configuración de vértices ----------

    fun setProposerCount(count: Int) = resize(count, _uiState.value.receiverNames.size)

    fun setReceiverCount(count: Int) = resize(_uiState.value.proposerNames.size, count)

    fun renameProposer(index: Int, name: String) = edit {
        copy(proposerNames = proposerNames.replaceAt(index, name))
    }

    fun renameReceiver(index: Int, name: String) = edit {
        copy(receiverNames = receiverNames.replaceAt(index, name))
    }

    private fun resize(newN: Int, newM: Int) = edit {
        val n = newN.coerceIn(1, MAX_NODES)
        val m = newM.coerceIn(1, MAX_NODES)
        copy(
            proposerNames = List(n) { proposerNames.getOrElse(it) { "u${it + 1}" } },
            receiverNames = List(m) { receiverNames.getOrElse(it) { "v${it + 1}" } },
            // Se conserva el orden previo y se añaden al final los nodos nuevos.
            proposerPrefs = List(n) { normalize(proposerPrefs.getOrNull(it).orEmpty(), m) },
            receiverPrefs = List(m) { normalize(receiverPrefs.getOrNull(it).orEmpty(), n) }
        )
    }

    // ---------- Matriz de preferencias ----------

    /** Mueve el elemento de la posición [from] a [to] en la lista del nodo [node]. */
    fun movePreference(side: Side, node: Int, from: Int, to: Int) = edit {
        fun List<List<Int>>.moved(): List<List<Int>> = mapIndexed { i, list ->
            if (i != node || to !in list.indices || from !in list.indices) list
            else list.toMutableList().apply { add(to, removeAt(from)) }
        }
        when (side) {
            Side.PROPOSERS -> copy(proposerPrefs = proposerPrefs.moved())
            Side.RECEIVERS -> copy(receiverPrefs = receiverPrefs.moved())
        }
    }

    fun randomizePreferences() = edit {
        val n = proposerNames.size
        val m = receiverNames.size
        copy(
            proposerPrefs = List(n) { (0 until m).shuffled() },
            receiverPrefs = List(m) { (0 until n).shuffled() }
        )
    }

    fun resetPreferences() = edit {
        val n = proposerNames.size
        val m = receiverNames.size
        copy(
            proposerPrefs = List(n) { (0 until m).toList() },
            receiverPrefs = List(m) { (0 until n).toList() }
        )
    }

    // ---------- Ejecución ----------

    fun setMode(mode: RunMode) = _uiState.update { it.copy(mode = mode) }

    fun solve() = _uiState.update { state ->
        val error = GaleShapleySolver.validate(state.profile)
        if (error != null) {
            state.copy(error = error, result = null, stepIndex = 0)
        } else {
            // La traza siempre se registra: permite cambiar de modo sin recalcular.
            state.copy(result = GaleShapleySolver.solve(state.profile), stepIndex = 0, error = null)
        }
    }

    fun nextStep() = moveStep { it + 1 }
    fun previousStep() = moveStep { it - 1 }
    fun restartSteps() = moveStep { 0 }
    fun jumpToEnd() = moveStep { Int.MAX_VALUE }

    private fun moveStep(transform: (Int) -> Int) = _uiState.update { state ->
        val total = state.result?.trace?.size ?: return@update state
        state.copy(stepIndex = transform(state.stepIndex).coerceIn(0, total))
    }

    // ---------- Utilidades ----------

    /** Toda edición invalida el resultado anterior. */
    private fun edit(block: GaleShapleyUiState.() -> GaleShapleyUiState) = _uiState.update {
        it.block().copy(result = null, stepIndex = 0, error = null)
    }

    private fun initialState(n: Int, m: Int) = GaleShapleyUiState(
        proposerNames = List(n) { "u${it + 1}" },
        receiverNames = List(m) { "v${it + 1}" },
        proposerPrefs = List(n) { (0 until m).toList() },
        receiverPrefs = List(m) { (0 until n).toList() }
    )

    private fun normalize(order: List<Int>, size: Int): List<Int> =
        order.filter { it < size } + (0 until size).filter { it !in order }

    private fun <T> List<T>.replaceAt(index: Int, value: T): List<T> =
        mapIndexed { i, old -> if (i == index) value else old }
}
